# DAPP STORE - website siap domain

Isi folder ini:
- index.html  : halaman utama (semua gambar sudah tertanam)
- favicon.svg : ikon tab browser
- robots.txt  : izinkan mesin pencari
- netlify.toml: pengaturan keamanan dasar untuk Netlify

## Pasang ke domain (cara paling mudah: Netlify)
1. Buat akun di netlify.com, lalu pilih Add new site > Deploy manually.
2. Seret file zip ini (atau folder berisi semua file di atas) ke halaman itu.
3. Buka Domain management > Add a domain, ketik domain kamu (contoh: namadomain.com).
4. Netlify menampilkan pengaturan DNS. Salin persis ke dashboard tempat kamu membeli domain
   (nameserver Netlify, atau record A untuk domain utama dan CNAME untuk www).
5. Tunggu beberapa menit sampai 24 jam. HTTPS (gembok) aktif otomatis.
6. Tes di jendela penyamaran dan di HP lain.

## Alternatif
- GitHub Pages: unggah semua file ke repository, aktifkan Pages, lalu buat file bernama CNAME
  berisi satu baris: namadomain.com
- Cloudflare Pages: unggah folder ini, lalu tambahkan Custom domain di pengaturan proyek.

## Mengubah isi
Nomor WhatsApp, link saluran, grup, DANA, GoPay, dan daftar layanan ada di bagian CONFIG
di dalam index.html (cari tulisan "const CONFIG").
